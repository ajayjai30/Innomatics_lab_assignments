// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getWeekYear as fn } from "../getWeekYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getWeekYear = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getWeekYear;
