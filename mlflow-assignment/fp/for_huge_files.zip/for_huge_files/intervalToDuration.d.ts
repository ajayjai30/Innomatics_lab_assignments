export declare const intervalToDuration: import("./types.js").FPFn1<
  import("../fp.js").Duration,
  import("../fp.js").Interval<Date>
>;
