// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isWeekend as fn } from "../isWeekend.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isWeekend = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isWeekend;
