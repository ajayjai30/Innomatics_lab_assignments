"use strict";
exports.getWeeksInMonth = void 0;

var _index = require("../getWeeksInMonth.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const getWeeksInMonth = (exports.getWeeksInMonth = (0, _index2.convertToFP)(
  _index.getWeeksInMonth,
  1,
));
