"use strict";
exports.isSameMonth = void 0;

var _index = require("../isSameMonth.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const isSameMonth = (exports.isSameMonth = (0, _index2.convertToFP)(
  _index.isSameMonth,
  2,
));
