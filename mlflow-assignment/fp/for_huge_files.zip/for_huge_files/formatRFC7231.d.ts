export declare const formatRFC7231: import("./types.js").FPFn1<
  string,
  string | number | Date
>;
