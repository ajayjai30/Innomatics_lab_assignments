"use strict";
exports.isSameHour = void 0;

var _index = require("../isSameHour.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const isSameHour = (exports.isSameHour = (0, _index2.convertToFP)(
  _index.isSameHour,
  2,
));
