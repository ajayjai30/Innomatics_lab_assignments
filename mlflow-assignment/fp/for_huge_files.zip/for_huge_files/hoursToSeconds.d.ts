export declare const hoursToSeconds: import("./types.js").FPFn1<number, number>;
