export declare const isSameISOWeekYear: import("./types.js").FPFn2<
  boolean,
  string | number | Date,
  string | number | Date
>;
