// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameDay as fn } from "../isSameDay.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameDay = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameDay;
