export declare const intlFormatDistanceWithOptions: import("./types.js").FPFn3<
  string,
  import("../intlFormatDistance.js").IntlFormatDistanceOptions | undefined,
  string | number | Date,
  string | number | Date
>;
