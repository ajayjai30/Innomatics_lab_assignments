export declare const formatDistanceWithOptions: import("./types.js").FPFn3<
  string,
  import("../formatDistance.js").FormatDistanceOptions | undefined,
  string | number | Date,
  string | number | Date
>;
