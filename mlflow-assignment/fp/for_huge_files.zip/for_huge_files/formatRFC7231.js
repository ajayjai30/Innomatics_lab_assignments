"use strict";
exports.formatRFC7231 = void 0;

var _index = require("../formatRFC7231.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatRFC7231 = (exports.formatRFC7231 = (0, _index2.convertToFP)(
  _index.formatRFC7231,
  1,
));
