// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameQuarter as fn } from "../isSameQuarter.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameQuarter = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameQuarter;
