"use strict";
exports.getWeekWithOptions = void 0;

var _index = require("../getWeek.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const getWeekWithOptions = (exports.getWeekWithOptions = (0,
_index2.convertToFP)(_index.getWeek, 2));
