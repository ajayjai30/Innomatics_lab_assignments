// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isExists as fn } from "../isExists.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isExists = convertToFP(fn, 3);

// Fallback for modularized imports:
export default isExists;
