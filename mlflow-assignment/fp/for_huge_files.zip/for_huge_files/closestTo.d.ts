export declare const closestTo: import("./types.js").FPFn2<
  Date | undefined,
  (string | number | Date)[],
  string | number | Date
>;
