"use strict";
exports.formatDurationWithOptions = void 0;

var _index = require("../formatDuration.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatDurationWithOptions = (exports.formatDurationWithOptions = (0,
_index2.convertToFP)(_index.formatDuration, 2));
