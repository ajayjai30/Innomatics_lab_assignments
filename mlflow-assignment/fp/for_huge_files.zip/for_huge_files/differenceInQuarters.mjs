// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInQuarters as fn } from "../differenceInQuarters.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInQuarters = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInQuarters;
