export declare const isWithinInterval: import("./types.js").FPFn2<
  boolean,
  import("../fp.js").Interval<Date>,
  string | number | Date
>;
