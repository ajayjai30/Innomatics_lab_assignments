// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { intlFormat as fn } from "../intlFormat.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const intlFormat = convertToFP(fn, 3);

// Fallback for modularized imports:
export default intlFormat;
