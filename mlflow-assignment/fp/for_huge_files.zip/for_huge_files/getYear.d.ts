export declare const getYear: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
