"use strict";
exports.getMilliseconds = void 0;

var _index = require("../getMilliseconds.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const getMilliseconds = (exports.getMilliseconds = (0, _index2.convertToFP)(
  _index.getMilliseconds,
  1,
));
