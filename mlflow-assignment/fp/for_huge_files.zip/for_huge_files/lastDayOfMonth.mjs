// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { lastDayOfMonth as fn } from "../lastDayOfMonth.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const lastDayOfMonth = convertToFP(fn, 1);

// Fallback for modularized imports:
export default lastDayOfMonth;
