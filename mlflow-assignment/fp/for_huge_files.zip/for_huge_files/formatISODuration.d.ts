export declare const formatISODuration: import("./types.js").FPFn1<
  string,
  import("../fp.js").Duration
>;
