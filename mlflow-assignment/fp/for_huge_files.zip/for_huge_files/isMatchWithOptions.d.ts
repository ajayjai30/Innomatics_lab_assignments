export declare const isMatchWithOptions: import("./types.js").FPFn3<
  boolean,
  import("../isMatch.js").IsMatchOptions | undefined,
  string,
  string
>;
