export declare const endOfDecade: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
