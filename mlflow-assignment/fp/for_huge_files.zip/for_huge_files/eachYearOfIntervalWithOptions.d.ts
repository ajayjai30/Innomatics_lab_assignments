export declare const eachYearOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachYearOfInterval.js").EachYearOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
