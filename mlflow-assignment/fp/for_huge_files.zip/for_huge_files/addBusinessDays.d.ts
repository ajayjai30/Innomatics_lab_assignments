export declare const addBusinessDays: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
