// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachMonthOfInterval as fn } from "../eachMonthOfInterval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachMonthOfInterval = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachMonthOfInterval;
