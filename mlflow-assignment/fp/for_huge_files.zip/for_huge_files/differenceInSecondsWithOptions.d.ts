export declare const differenceInSecondsWithOptions: import("./types.js").FPFn3<
  number,
  import("../differenceInSeconds.js").DifferenceInSecondsOptions | undefined,
  string | number | Date,
  string | number | Date
>;
