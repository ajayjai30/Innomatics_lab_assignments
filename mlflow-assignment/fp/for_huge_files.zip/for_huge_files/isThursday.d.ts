export declare const isThursday: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
