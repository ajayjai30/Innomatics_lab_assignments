// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { interval as fn } from "../interval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const interval = convertToFP(fn, 2);

// Fallback for modularized imports:
export default interval;
