export declare const getMonth: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
