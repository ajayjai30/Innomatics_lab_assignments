// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameWeek as fn } from "../isSameWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameWeek = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameWeek;
