// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameISOWeek as fn } from "../isSameISOWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameISOWeek = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameISOWeek;
