export declare const format: import("./types.js").FPFn2<
  string,
  string,
  string | number | Date
>;
