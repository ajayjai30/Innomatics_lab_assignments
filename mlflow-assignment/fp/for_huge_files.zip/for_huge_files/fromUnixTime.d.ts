export declare const fromUnixTime: import("./types.js").FPFn1<Date, number>;
