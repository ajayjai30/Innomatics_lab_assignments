"use strict";
exports.addMonths = void 0;

var _index = require("../addMonths.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const addMonths = (exports.addMonths = (0, _index2.convertToFP)(
  _index.addMonths,
  2,
));
