export declare const isValid: import("./types.js").FPFn1<boolean, unknown>;
