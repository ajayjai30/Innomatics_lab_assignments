export declare const interval: import("./types.js").FPFn2<
  import("../fp.js").NormalizedInterval<Date>,
  string | number | Date,
  string | number | Date
>;
