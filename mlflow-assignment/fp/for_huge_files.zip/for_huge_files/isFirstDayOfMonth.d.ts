export declare const isFirstDayOfMonth: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
