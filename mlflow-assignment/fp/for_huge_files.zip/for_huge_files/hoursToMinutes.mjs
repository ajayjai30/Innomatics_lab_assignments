// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { hoursToMinutes as fn } from "../hoursToMinutes.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const hoursToMinutes = convertToFP(fn, 1);

// Fallback for modularized imports:
export default hoursToMinutes;
