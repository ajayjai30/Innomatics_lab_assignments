export declare const getWeekWithOptions: import("./types.js").FPFn2<
  number,
  import("../getWeek.js").GetWeekOptions | undefined,
  string | number | Date
>;
