export declare const formatWithOptions: import("./types.js").FPFn3<
  string,
  import("../format.js").FormatDateOptions | undefined,
  string,
  string | number | Date
>;
