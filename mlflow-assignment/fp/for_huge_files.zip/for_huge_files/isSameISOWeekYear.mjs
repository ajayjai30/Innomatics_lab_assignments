// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameISOWeekYear as fn } from "../isSameISOWeekYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameISOWeekYear = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameISOWeekYear;
