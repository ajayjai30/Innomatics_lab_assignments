export declare const formatRFC3339WithOptions: import("./types.js").FPFn2<
  string,
  import("../formatRFC3339.js").FormatRFC3339Options | undefined,
  string | number | Date
>;
