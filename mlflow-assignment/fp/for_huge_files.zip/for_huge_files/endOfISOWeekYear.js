"use strict";
exports.endOfISOWeekYear = void 0;

var _index = require("../endOfISOWeekYear.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const endOfISOWeekYear = (exports.endOfISOWeekYear = (0, _index2.convertToFP)(
  _index.endOfISOWeekYear,
  1,
));
