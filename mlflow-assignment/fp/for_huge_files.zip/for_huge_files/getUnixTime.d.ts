export declare const getUnixTime: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
