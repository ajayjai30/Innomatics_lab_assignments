// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameYear as fn } from "../isSameYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameYear = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameYear;
