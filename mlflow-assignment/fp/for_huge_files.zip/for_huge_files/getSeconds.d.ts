export declare const getSeconds: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
