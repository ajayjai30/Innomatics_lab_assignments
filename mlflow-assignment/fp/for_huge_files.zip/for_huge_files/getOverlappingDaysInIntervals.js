"use strict";
exports.getOverlappingDaysInIntervals = void 0;

var _index = require("../getOverlappingDaysInIntervals.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const getOverlappingDaysInIntervals = (exports.getOverlappingDaysInIntervals =
  (0, _index2.convertToFP)(_index.getOverlappingDaysInIntervals, 2));
