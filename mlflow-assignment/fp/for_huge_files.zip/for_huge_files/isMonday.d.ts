export declare const isMonday: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
