export declare const isSameDay: import("./types.js").FPFn2<
  boolean,
  string | number | Date,
  string | number | Date
>;
