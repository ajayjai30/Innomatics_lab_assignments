export declare const hoursToMinutes: import("./types.js").FPFn1<number, number>;
