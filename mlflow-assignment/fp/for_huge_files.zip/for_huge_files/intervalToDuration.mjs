// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { intervalToDuration as fn } from "../intervalToDuration.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const intervalToDuration = convertToFP(fn, 1);

// Fallback for modularized imports:
export default intervalToDuration;
