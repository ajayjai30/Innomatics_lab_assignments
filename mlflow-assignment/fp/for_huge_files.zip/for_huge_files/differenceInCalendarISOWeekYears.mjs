// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInCalendarISOWeekYears as fn } from "../differenceInCalendarISOWeekYears.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInCalendarISOWeekYears = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInCalendarISOWeekYears;
