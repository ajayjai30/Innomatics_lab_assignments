export declare const getHours: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
