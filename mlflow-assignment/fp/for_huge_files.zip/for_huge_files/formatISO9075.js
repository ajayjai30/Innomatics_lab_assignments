"use strict";
exports.formatISO9075 = void 0;

var _index = require("../formatISO9075.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatISO9075 = (exports.formatISO9075 = (0, _index2.convertToFP)(
  _index.formatISO9075,
  1,
));
