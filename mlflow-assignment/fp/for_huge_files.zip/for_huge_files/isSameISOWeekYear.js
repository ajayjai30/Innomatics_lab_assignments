"use strict";
exports.isSameISOWeekYear = void 0;

var _index = require("../isSameISOWeekYear.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const isSameISOWeekYear = (exports.isSameISOWeekYear = (0, _index2.convertToFP)(
  _index.isSameISOWeekYear,
  2,
));
