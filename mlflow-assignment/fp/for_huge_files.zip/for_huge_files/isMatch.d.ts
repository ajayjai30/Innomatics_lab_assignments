export declare const isMatch: import("./types.js").FPFn2<
  boolean,
  string,
  string
>;
