export declare const intlFormat: import("./types.js").FPFn3<
  string,
  import("../intlFormat.js").IntlFormatLocaleOptions,
  Intl.DateTimeFormatOptions,
  string | number | Date
>;
