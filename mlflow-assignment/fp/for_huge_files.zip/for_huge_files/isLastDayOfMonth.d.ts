export declare const isLastDayOfMonth: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
