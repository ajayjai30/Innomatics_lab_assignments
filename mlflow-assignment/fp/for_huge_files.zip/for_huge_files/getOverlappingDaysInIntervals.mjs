// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getOverlappingDaysInIntervals as fn } from "../getOverlappingDaysInIntervals.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getOverlappingDaysInIntervals = convertToFP(fn, 2);

// Fallback for modularized imports:
export default getOverlappingDaysInIntervals;
