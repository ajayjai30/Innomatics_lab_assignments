export declare const getWeeksInMonthWithOptions: import("./types.js").FPFn2<
  number,
  import("../getWeeksInMonth.js").GetWeeksInMonthOptions | undefined,
  string | number | Date
>;
