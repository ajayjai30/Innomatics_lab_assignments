// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatRelative as fn } from "../formatRelative.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatRelativeWithOptions = convertToFP(fn, 3);

// Fallback for modularized imports:
export default formatRelativeWithOptions;
