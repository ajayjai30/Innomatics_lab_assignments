export declare const endOfQuarter: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
