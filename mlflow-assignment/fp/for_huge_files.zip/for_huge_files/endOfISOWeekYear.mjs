// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { endOfISOWeekYear as fn } from "../endOfISOWeekYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const endOfISOWeekYear = convertToFP(fn, 1);

// Fallback for modularized imports:
export default endOfISOWeekYear;
