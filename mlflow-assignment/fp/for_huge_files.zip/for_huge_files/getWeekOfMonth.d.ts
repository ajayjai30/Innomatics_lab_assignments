export declare const getWeekOfMonth: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
