// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameMinute as fn } from "../isSameMinute.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameMinute = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameMinute;
