"use strict";
exports.isSaturday = void 0;

var _index = require("../isSaturday.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const isSaturday = (exports.isSaturday = (0, _index2.convertToFP)(
  _index.isSaturday,
  1,
));
