// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { endOfMonth as fn } from "../endOfMonth.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const endOfMonth = convertToFP(fn, 1);

// Fallback for modularized imports:
export default endOfMonth;
