"use strict";
exports.addMinutes = void 0;

var _index = require("../addMinutes.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const addMinutes = (exports.addMinutes = (0, _index2.convertToFP)(
  _index.addMinutes,
  2,
));
