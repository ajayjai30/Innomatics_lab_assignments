"use strict";
exports.differenceInDays = void 0;

var _index = require("../differenceInDays.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInDays = (exports.differenceInDays = (0, _index2.convertToFP)(
  _index.differenceInDays,
  2,
));
