export declare const eachMinuteOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachMinuteOfInterval.js").EachMinuteOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
