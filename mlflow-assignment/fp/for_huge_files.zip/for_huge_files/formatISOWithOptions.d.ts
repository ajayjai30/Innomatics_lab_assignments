export declare const formatISOWithOptions: import("./types.js").FPFn2<
  string,
  import("../formatISO.js").FormatISOOptions | undefined,
  string | number | Date
>;
