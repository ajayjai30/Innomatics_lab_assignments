// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { lastDayOfDecade as fn } from "../lastDayOfDecade.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const lastDayOfDecade = convertToFP(fn, 1);

// Fallback for modularized imports:
export default lastDayOfDecade;
