export declare const getISOWeeksInYear: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
