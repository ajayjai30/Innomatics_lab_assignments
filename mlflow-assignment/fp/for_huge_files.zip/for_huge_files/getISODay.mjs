// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getISODay as fn } from "../getISODay.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getISODay = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getISODay;
