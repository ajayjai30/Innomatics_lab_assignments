"use strict";
exports.differenceInHoursWithOptions = void 0;

var _index = require("../differenceInHours.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInHoursWithOptions = (exports.differenceInHoursWithOptions = (0,
_index2.convertToFP)(_index.differenceInHours, 3));
