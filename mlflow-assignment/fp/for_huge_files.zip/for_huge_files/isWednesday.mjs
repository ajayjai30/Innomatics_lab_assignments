// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isWednesday as fn } from "../isWednesday.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isWednesday = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isWednesday;
