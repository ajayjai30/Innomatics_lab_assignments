export declare const getMilliseconds: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
