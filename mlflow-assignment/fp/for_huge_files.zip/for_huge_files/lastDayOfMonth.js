"use strict";
exports.lastDayOfMonth = void 0;

var _index = require("../lastDayOfMonth.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const lastDayOfMonth = (exports.lastDayOfMonth = (0, _index2.convertToFP)(
  _index.lastDayOfMonth,
  1,
));
