export declare const getWeeksInMonth: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
