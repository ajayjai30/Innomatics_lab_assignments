// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInYears as fn } from "../differenceInYears.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInYears = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInYears;
