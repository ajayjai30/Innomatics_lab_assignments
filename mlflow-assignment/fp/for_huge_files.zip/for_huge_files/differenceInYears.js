"use strict";
exports.differenceInYears = void 0;

var _index = require("../differenceInYears.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInYears = (exports.differenceInYears = (0, _index2.convertToFP)(
  _index.differenceInYears,
  2,
));
