export declare const getDecade: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
