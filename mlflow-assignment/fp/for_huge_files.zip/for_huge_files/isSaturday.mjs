// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSaturday as fn } from "../isSaturday.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSaturday = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isSaturday;
