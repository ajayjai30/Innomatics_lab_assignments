export declare const formatRelativeWithOptions: import("./types.js").FPFn3<
  string,
  import("../formatRelative.js").FormatRelativeOptions | undefined,
  string | number | Date,
  string | number | Date
>;
