export declare const daysToWeeks: import("./types.js").FPFn1<number, number>;
