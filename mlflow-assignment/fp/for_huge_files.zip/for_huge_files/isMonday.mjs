// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isMonday as fn } from "../isMonday.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isMonday = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isMonday;
