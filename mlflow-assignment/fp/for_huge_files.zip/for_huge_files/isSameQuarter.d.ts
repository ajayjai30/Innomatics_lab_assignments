export declare const isSameQuarter: import("./types.js").FPFn2<
  boolean,
  string | number | Date,
  string | number | Date
>;
