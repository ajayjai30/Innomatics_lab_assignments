export declare const isDate: import("./types.js").FPFn1<boolean, unknown>;
