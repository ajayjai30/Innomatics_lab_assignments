// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameSecond as fn } from "../isSameSecond.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameSecond = convertToFP(fn, 2);

// Fallback for modularized imports:
export default isSameSecond;
