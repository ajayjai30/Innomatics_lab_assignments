"use strict";
exports.isEqual = void 0;

var _index = require("../isEqual.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const isEqual = (exports.isEqual = (0, _index2.convertToFP)(_index.isEqual, 2));
