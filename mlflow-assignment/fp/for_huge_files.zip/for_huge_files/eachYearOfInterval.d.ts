export declare const eachYearOfInterval: import("./types.js").FPFn1<
  Date[],
  import("../fp.js").Interval<Date>
>;
