export declare const formatRFC3339: import("./types.js").FPFn1<
  string,
  string | number | Date
>;
