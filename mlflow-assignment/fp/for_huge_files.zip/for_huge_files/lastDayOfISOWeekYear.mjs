// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { lastDayOfISOWeekYear as fn } from "../lastDayOfISOWeekYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const lastDayOfISOWeekYear = convertToFP(fn, 1);

// Fallback for modularized imports:
export default lastDayOfISOWeekYear;
