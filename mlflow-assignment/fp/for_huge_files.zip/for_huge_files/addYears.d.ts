export declare const addYears: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
