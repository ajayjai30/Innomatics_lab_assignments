// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getISOWeeksInYear as fn } from "../getISOWeeksInYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getISOWeeksInYear = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getISOWeeksInYear;
