"use strict";
exports.formatRFC3339WithOptions = void 0;

var _index = require("../formatRFC3339.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatRFC3339WithOptions = (exports.formatRFC3339WithOptions = (0,
_index2.convertToFP)(_index.formatRFC3339, 2));
