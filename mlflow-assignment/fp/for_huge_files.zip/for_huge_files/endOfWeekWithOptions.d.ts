export declare const endOfWeekWithOptions: import("./types.js").FPFn2<
  Date,
  import("../endOfWeek.js").EndOfWeekOptions | undefined,
  string | number | Date
>;
