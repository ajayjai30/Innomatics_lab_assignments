export declare const isWednesday: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
