export declare const lastDayOfQuarter: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
