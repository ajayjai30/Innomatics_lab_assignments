export declare const getMinutes: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
