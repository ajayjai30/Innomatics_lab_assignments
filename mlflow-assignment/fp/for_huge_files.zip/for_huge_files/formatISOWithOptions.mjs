// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatISO as fn } from "../formatISO.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatISOWithOptions = convertToFP(fn, 2);

// Fallback for modularized imports:
export default formatISOWithOptions;
