// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getISOWeek as fn } from "../getISOWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getISOWeek = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getISOWeek;
