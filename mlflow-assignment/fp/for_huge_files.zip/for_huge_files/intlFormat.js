"use strict";
exports.intlFormat = void 0;

var _index = require("../intlFormat.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const intlFormat = (exports.intlFormat = (0, _index2.convertToFP)(
  _index.intlFormat,
  3,
));
