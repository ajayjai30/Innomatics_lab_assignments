// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getMonth as fn } from "../getMonth.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getMonth = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getMonth;
