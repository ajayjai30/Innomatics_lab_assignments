export declare const formatDuration: import("./types.js").FPFn1<
  string,
  import("../fp.js").Duration
>;
