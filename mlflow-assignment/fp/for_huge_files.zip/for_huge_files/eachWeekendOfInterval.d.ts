export declare const eachWeekendOfInterval: import("./types.js").FPFn1<
  Date[],
  import("../fp.js").Interval<Date>
>;
