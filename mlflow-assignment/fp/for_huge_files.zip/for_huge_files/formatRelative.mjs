// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatRelative as fn } from "../formatRelative.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatRelative = convertToFP(fn, 2);

// Fallback for modularized imports:
export default formatRelative;
