export declare const getOverlappingDaysInIntervals: import("./types.js").FPFn2<
  number,
  import("../fp.js").Interval<Date>,
  import("../fp.js").Interval<Date>
>;
