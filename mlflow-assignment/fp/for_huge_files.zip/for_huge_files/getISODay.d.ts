export declare const getISODay: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
