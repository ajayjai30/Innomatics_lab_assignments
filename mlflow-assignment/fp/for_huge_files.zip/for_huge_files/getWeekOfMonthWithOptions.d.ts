export declare const getWeekOfMonthWithOptions: import("./types.js").FPFn2<
  number,
  import("../getWeekOfMonth.js").GetWeekOfMonthOptions | undefined,
  string | number | Date
>;
