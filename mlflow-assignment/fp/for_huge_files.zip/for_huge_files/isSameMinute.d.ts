export declare const isSameMinute: import("./types.js").FPFn2<
  boolean,
  string | number | Date,
  string | number | Date
>;
