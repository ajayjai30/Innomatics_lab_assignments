export declare const areIntervalsOverlappingWithOptions: import("./types.js").FPFn3<
  boolean,
  | import("../areIntervalsOverlapping.js").AreIntervalsOverlappingOptions
  | undefined,
  import("../fp.js").Interval<Date>,
  import("../fp.js").Interval<Date>
>;
