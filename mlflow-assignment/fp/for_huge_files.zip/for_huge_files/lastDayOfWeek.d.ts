export declare const lastDayOfWeek: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
