export declare const isWeekend: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
