"use strict";
exports.hoursToMilliseconds = void 0;

var _index = require("../hoursToMilliseconds.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const hoursToMilliseconds = (exports.hoursToMilliseconds = (0,
_index2.convertToFP)(_index.hoursToMilliseconds, 1));
