"use strict";
exports.getDaysInMonth = void 0;

var _index = require("../getDaysInMonth.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const getDaysInMonth = (exports.getDaysInMonth = (0, _index2.convertToFP)(
  _index.getDaysInMonth,
  1,
));
