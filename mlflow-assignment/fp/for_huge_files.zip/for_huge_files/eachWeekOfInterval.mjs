// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachWeekOfInterval as fn } from "../eachWeekOfInterval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachWeekOfInterval = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachWeekOfInterval;
