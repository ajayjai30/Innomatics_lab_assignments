export declare const isSameWeekWithOptions: import("./types.js").FPFn3<
  boolean,
  import("../isSameWeek.js").IsSameWeekOptions | undefined,
  string | number | Date,
  string | number | Date
>;
