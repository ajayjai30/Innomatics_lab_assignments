"use strict";
exports.differenceInMinutesWithOptions = void 0;

var _index = require("../differenceInMinutes.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInMinutesWithOptions = (exports.differenceInMinutesWithOptions =
  (0, _index2.convertToFP)(_index.differenceInMinutes, 3));
