export declare const intervalWithOptions: import("./types.js").FPFn3<
  import("../fp.js").NormalizedInterval<Date>,
  import("../interval.js").IntervalOptions | undefined,
  string | number | Date,
  string | number | Date
>;
