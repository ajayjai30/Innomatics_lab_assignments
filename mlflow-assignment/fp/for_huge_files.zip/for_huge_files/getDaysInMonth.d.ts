export declare const getDaysInMonth: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
