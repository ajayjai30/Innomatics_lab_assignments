export declare const formatISO9075: import("./types.js").FPFn1<
  string,
  string | number | Date
>;
