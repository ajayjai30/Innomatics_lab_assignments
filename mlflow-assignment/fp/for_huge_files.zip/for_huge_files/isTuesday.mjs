// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isTuesday as fn } from "../isTuesday.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isTuesday = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isTuesday;
