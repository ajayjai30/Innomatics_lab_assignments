// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getDay as fn } from "../getDay.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getDay = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getDay;
