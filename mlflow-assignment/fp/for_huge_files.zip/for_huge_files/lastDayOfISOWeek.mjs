// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { lastDayOfISOWeek as fn } from "../lastDayOfISOWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const lastDayOfISOWeek = convertToFP(fn, 1);

// Fallback for modularized imports:
export default lastDayOfISOWeek;
