export declare const isExists: import("./types.js").FPFn3<
  boolean,
  number,
  number,
  number
>;
