// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachWeekendOfInterval as fn } from "../eachWeekendOfInterval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachWeekendOfInterval = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachWeekendOfInterval;
