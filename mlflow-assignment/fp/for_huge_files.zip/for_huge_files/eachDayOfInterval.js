"use strict";
exports.eachDayOfInterval = void 0;

var _index = require("../eachDayOfInterval.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const eachDayOfInterval = (exports.eachDayOfInterval = (0, _index2.convertToFP)(
  _index.eachDayOfInterval,
  1,
));
