export declare const isFriday: import("./types.js").FPFn1<
  boolean,
  string | number | Date
>;
