// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isFirstDayOfMonth as fn } from "../isFirstDayOfMonth.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isFirstDayOfMonth = convertToFP(fn, 1);

// Fallback for modularized imports:
export default isFirstDayOfMonth;
