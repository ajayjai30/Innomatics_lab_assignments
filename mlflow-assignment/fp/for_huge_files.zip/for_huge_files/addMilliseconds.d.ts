export declare const addMilliseconds: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
