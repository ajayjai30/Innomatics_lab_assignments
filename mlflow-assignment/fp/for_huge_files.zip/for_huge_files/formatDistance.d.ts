export declare const formatDistance: import("./types.js").FPFn2<
  string,
  string | number | Date,
  string | number | Date
>;
