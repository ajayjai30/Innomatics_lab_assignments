// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { isSameWeek as fn } from "../isSameWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const isSameWeekWithOptions = convertToFP(fn, 3);

// Fallback for modularized imports:
export default isSameWeekWithOptions;
