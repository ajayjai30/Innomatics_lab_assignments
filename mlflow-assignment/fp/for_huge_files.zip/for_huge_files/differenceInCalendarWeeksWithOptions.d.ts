export declare const differenceInCalendarWeeksWithOptions: import("./types.js").FPFn3<
  number,
  | import("../differenceInCalendarWeeks.js").DifferenceInCalendarWeeksOptions
  | undefined,
  string | number | Date,
  string | number | Date
>;
