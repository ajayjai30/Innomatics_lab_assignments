"use strict";
exports.differenceInMonths = void 0;

var _index = require("../differenceInMonths.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInMonths = (exports.differenceInMonths = (0,
_index2.convertToFP)(_index.differenceInMonths, 2));
