export declare const lastDayOfDecade: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
