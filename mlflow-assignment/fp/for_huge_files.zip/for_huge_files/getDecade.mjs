// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { getDecade as fn } from "../getDecade.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const getDecade = convertToFP(fn, 1);

// Fallback for modularized imports:
export default getDecade;
