export declare const hoursToMilliseconds: import("./types.js").FPFn1<
  number,
  number
>;
