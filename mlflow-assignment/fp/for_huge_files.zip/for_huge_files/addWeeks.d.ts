export declare const addWeeks: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
