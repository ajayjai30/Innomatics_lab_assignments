// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInWeeks as fn } from "../differenceInWeeks.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInWeeks = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInWeeks;
