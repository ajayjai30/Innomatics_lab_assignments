export declare const addHours: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
