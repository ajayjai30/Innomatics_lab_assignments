export declare const getWeekYearWithOptions: import("./types.js").FPFn2<
  number,
  import("../getWeekYear.js").GetWeekYearOptions | undefined,
  string | number | Date
>;
