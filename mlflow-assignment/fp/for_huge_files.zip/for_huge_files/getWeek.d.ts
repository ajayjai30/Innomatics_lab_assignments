export declare const getWeek: import("./types.js").FPFn1<
  number,
  string | number | Date
>;
