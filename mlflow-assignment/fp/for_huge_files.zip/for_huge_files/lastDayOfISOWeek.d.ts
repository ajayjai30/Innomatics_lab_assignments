export declare const lastDayOfISOWeek: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
