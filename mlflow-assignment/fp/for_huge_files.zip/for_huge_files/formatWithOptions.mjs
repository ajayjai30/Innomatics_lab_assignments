// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { format as fn } from "../format.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatWithOptions = convertToFP(fn, 3);

// Fallback for modularized imports:
export default formatWithOptions;
