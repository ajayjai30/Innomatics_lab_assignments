// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatRFC7231 as fn } from "../formatRFC7231.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatRFC7231 = convertToFP(fn, 1);

// Fallback for modularized imports:
export default formatRFC7231;
